package com.example.projectmanagement.ui.adapter;

public interface ReloadableAdapter {
    void reload();
    void startAutoReload();
    void stopAutoReload();
} 